(function () {
  Cu.import("resource:///modules/AboutNewTab.jsm");  
  var newTabURL = "file:///home/USERNAME/.mozilla/firefox/PROFILE NAME/chrome/startpage/index.html";  
  AboutNewTab.newTabURL = newTabURL;
})();
